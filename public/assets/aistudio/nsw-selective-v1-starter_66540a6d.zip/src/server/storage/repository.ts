import type {
  BankImportManifest, LearningConfig, PartAttemptRecord, QuestionItem,
  QuestionMemoryState, SessionRecord, SkillState, StimulusGroup, WritingEvaluationRecord
} from '../../shared/contracts';

export interface WritingSubmissionRecord {
  submissionId: string;
  sessionId: string;
  questionId: string;
  planNotes: string;
  responseText: string;
  wordCount: number;
  timeSpentSec: number;
  deterministicMetricsJson: string;
  submittedAt: string;
}

export interface AppRepository {
  readonly backendName: 'cloudsql_postgres' | 'firestore_server' | 'cloudflare_d1' | 'memory_preview';
  initAndSeedIfEmpty(seedManifest: BankImportManifest): Promise<void>;

  listQuestions(filter?: { section?: string; poolType?: string; qcStatus?: string }): Promise<QuestionItem[]>;
  getQuestionWithStimulus(questionId: string): Promise<{ question: QuestionItem; stimulus?: StimulusGroup } | null>;
  importManifest(manifest: BankImportManifest): Promise<{ imported: number; skipped: number; versionBumped: number }>;
  updateQuestionStatus(questionId: string, qcStatus: QuestionItem['qcStatus']): Promise<void>;

  getActiveConfig(): Promise<{ configVersionId: string; versionNumber: number; config: LearningConfig }>;
  saveConfigVersion(config: LearningConfig, notes?: string): Promise<{ configVersionId: string; versionNumber: number }>;

  createSession(session: SessionRecord): Promise<void>;
  getSession(sessionId: string): Promise<SessionRecord | null>;
  saveSessionCheckpoint(sessionId: string, checkpoint: NonNullable<SessionRecord['checkpoint']>): Promise<void>;
  completeSession(sessionId: string, summary: { correctSlots: number; totalSlots: number; completedAt: string }): Promise<void>;
  listSessions(limit?: number): Promise<SessionRecord[]>;

  appendPartAttempts(attempts: PartAttemptRecord[]): Promise<void>;
  listPartAttempts(limit?: number): Promise<PartAttemptRecord[]>;

  saveWritingSubmission(sub: WritingSubmissionRecord): Promise<void>;
  listWritingSubmissions(): Promise<(WritingSubmissionRecord & { evaluations: WritingEvaluationRecord[] })[]>;
  saveWritingEvaluation(ev: WritingEvaluationRecord): Promise<void>;

  getSkillStates(): Promise<Record<string, SkillState>>;
  upsertSkillStates(states: SkillState[]): Promise<void>;
  getQuestionMemory(): Promise<Record<string, QuestionMemoryState>>;
  upsertQuestionMemory(entries: QuestionMemoryState[]): Promise<void>;

  exportFullBackup(): Promise<Record<string, unknown>>;
}