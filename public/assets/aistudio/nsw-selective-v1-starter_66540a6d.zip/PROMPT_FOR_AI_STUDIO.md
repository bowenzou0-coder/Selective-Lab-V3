Build the **NSW Selective Test Adaptive Learning App (V1)** targeting the May 2027 NSW Selective High School Placement Test.

### 1. Architecture & Portability Rules
- **Frontend (`src/client/`):** React + Vite + TypeScript SPA talking ONLY via `fetch('/api/...')`. Never import Firebase, Cloud SQL, or Google AI SDKs in browser code.
- **Backend (`src/server/`):** Node.js + Express + TypeScript ESM serving both `/api/*` and the built React app for Cloud Run.
- **Database:** Use **Cloud SQL for PostgreSQL** via `src/server/storage/postgresRepository.ts` implementing the provided `AppRepository` interface (`src/server/storage/repository.ts`). Include a clean in-memory fallback ONLY if Cloud SQL/Postgres env vars are not yet connected in sandbox preview (show a warning banner in `/admin` when running in ephemeral preview mode). Do NOT add Firebase Auth or Google Sign-In.
- **Core Files:** Use the provided `src/shared/contracts.ts`, `src/shared/skills.ts`, `src/shared/engine.ts`, and `src/client/styles/tokens.css`. On startup, seed from `seed/golden-smoke-pack.json` if empty.

### 2. Auth & Security (Shared URL, No Google Account)
- The student uses the published Cloud Run URL without a Google account.
- Gate student routes (`/api/student/*`) with an **App PIN screen** verified against `process.env.STUDENT_PIN || '1234'` via an HMAC-SHA256 `HttpOnly` cookie (`SESSION_SECRET` env var, 30-day expiry).
- Gate `/admin` UI and `/api/admin/*` with `process.env.ADMIN_PASSWORD || 'admin-dev'`. Student cookies MUST receive `HTTP 403` on `/api/admin/*`.
- **ZERO ANSWER KEY LEAKAGE:** `GET /api/student/sessions/:id` MUST return `StudentQuestionView` (never `correctAnswerKey`, `workedExplanation`, or `distractorRationales`). Return answers and explanations ONLY after persisting `part_attempts` on submit.

### 3. Aesthetic (Claude Code-Inspired Warm Minimal)
- Use `src/client/styles/tokens.css` (`#FAF9F5` background, `#F3F1EC` cards, `#1F1E1D` ink, `#E5E0D8` 1px borders, `#D97757` terracotta accent, `#2E6F40` sage correct state).
- Use `--font-sans`, `--font-serif` (for Reading passages), and `--font-mono` (`font-variant-numeric: tabular-nums` for timers/scores) so custom `.woff2` fonts in `public/fonts/` drop in automatically.
- Fast, crisp, distraction-free UI with MCQ keyboard shortcuts (`1–5` / `A–E`, `N`/`P`, `F` flag).

### 4. V1 Screens & Features
1. **Home (`/`):** Minimalist entry ("Start Today's Practice" primary button, quick section drill pills for Reading / Maths / Thinking Skills / Writing, today's target & streak, subtle footer link to `/admin`).
2. **Practice / Exam Player (`/session/:id`):**
   - Header: hideable countdown timer, slot counter, Flag button, Question Navigator grid, "No calculator / dictionary" badge.
   - Autosave checkpoint on answer change and every 30s; browser reload restores exact draft answers and timer.
   - **VisualRenderer component:** Safely renders `inline_svg`, `structured_table`, and `image_asset` (with caption + click-to-zoom).
   - **All 4 Sections & 5 Reading Mechanics:**
     - Reading Part 1 (Fiction MCQ) & Part 3 (Poetry MCQ): split passage + question view.
     - Reading Part 2 (Vocabulary Cloze): full passage with inline `<select>` dropdowns replacing `{{gap:1}}..{{gap:N}}`.
     - Reading Part 4 (Gapped Text): passage with clickable `{{gap:1}}..{{gap:N}}` slots + shared extract bank; enforce `reuseAllowed: false` so placing an extract moves it cleanly instead of duplicating across two gaps.
     - Reading Part 5 (Multiple Matching): extracts A–D + statement list with A/B/C/D selector pills.
     - Mathematical Reasoning: 5 options `A–E` + optional SVG/table visual.
     - Thinking Skills: 4 options `A–D` + optional rule callout + optional SVG option tiles.
     - Writing: 30-min timer, collapsible scratchpad plan, plain-text editor with `spellCheck={false}`, live word counter, mandatory opening-line check, and optional visual stimulus panel.
   - **Post-Submission Review:** Deterministic score, worked explanations, distractor rationales, "Flag issue" button. On Writing submit, show deterministic `WritingDeterministicMetrics` immediately plus an optional **"Get Gemini Writing Feedback"** button calling `@google/genai` on the server (`GEMINI_API_KEY`).
3. **Progress (`/progress`):** Section accuracy & avg pace vs target pace, skill mastery grouped by family, session history, Writing archive, CSV/JSON report download.
4. **Admin (`/admin`):**
   - **Bank Importer:** Upload/paste `BankImportManifest` JSON → dry-run validation & hash check → commit (version-bump edits without deleting historical attempts).
   - **Question QC & Visual Manager:** Preview SVGs/images, upload/attach image assets, toggle `active` / `quarantined`, verify `benchmark_holdout` isolation.
   - **Config Editor:** Edit section weights, daily limits, target success range, SM-2 params, and plateau thresholds → saves a new immutable `admin_config_versions` record.
   - **Full Backup Export:** Download complete JSON backup of bank, configs, attempts, skill states, and writing submissions.