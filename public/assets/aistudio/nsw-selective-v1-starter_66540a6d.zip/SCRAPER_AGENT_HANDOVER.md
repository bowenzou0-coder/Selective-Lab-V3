# Scraper Agent Handover — Official NSW DoE Practice Tests

## Source integrity
`raw/download_manifest.json` lists all 30 official PDFs with URLs, SHA-256 and download date. Re-verify with:

```sh
python3 - <<'PY'
import hashlib, json
for e in json.load(open('raw/download_manifest.json')):
    h = hashlib.sha256(open('raw/official_doe/' + e['filename'], 'rb').read()).hexdigest()
    assert h == e['sha256'], e['filename']
print('all PDFs match manifest')
PY
```

## Coverage
All four sections × Practice Tests 1–3, converted to the `BankImportManifest` schema:

| Section | Format | Items/test | Notes |
|---|---|---|---|
| Reading | paired extracts, vocab cloze (8), poetry, gapped text (6), multiple match (10) | 38 parts | PT3 gapped text is paragraph-summary matching |
| Mathematical Reasoning | `MATH_MCQ_5` | 35 | strictly A–E |
| Thinking Skills | `THINK_MCQ_4` | 40 | strictly A–D |
| Writing | `WRIT_TYPED_TASK` | 1 | PT3 has mandatoryOpeningLine |

Pool assignment: PT1 & PT2 → `official_calibration` (`seed/official-doe-pt1-2.json`).
PT3 → `benchmark_holdout` (`seed/official-doe-pt3-holdout.json`) — engine never surfaces it in `daily_adaptive`.

## Known quirks / decisions
- **Reading answer keys for PT1 & PT2 are defective** (Q9–16 Cloze omitted, later numbers shifted). All answer keys in the seed files were taken from the **Explained Answers** PDFs and cross-checked against the Question Papers and the standalone keys (PT1 maths, all thinking-skills, and PT3 keys match exactly; PT2 maths key matches explained answers too).
- Diagrams: simple figures were rebuilt as `inline_svg` (palette `#FAF9F5`/`#1F1E1D`/`#D97757`/`#3B5B6D`) or `structured_table`. Complex or photo-like figures were cropped at 200 dpi into `public/assets/official/` as `image_asset` with alt text (e.g. scales, protractors, map/illustration figures, spinners with needles, option-image questions).
- Provenance: every official item has `provenance.sourceType: "official_doe"`, `sourceReference: "NSW DoE <Section> PT<n> Q<N>"`, `verifierAgreed: true`, `auditorReviewed: true`.
- Licensing: raw PDFs are copyrighted; keep `raw/` private and gitignored. The seed JSON contains transcribed content for personal study use.
